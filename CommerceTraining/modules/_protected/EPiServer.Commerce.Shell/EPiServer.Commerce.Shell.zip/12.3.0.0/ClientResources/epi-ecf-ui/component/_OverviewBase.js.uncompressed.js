﻿define("epi-ecf-ui/component/_OverviewBase", [
// dojo
    "dojo/_base/declare",
    "dojo/dom-geometry",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin"
], function (
// dojo
    declare,
    domGeometry,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // summary:
        //      This is the base class for PricingOverview and InventoryOverview

        updateView: function (data, context) {
            // summary:
            //		Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //		protected

            this.toolbar.update({
                currentContext: context,
                viewConfigurations: {
                    availableViews: data.availableViews,
                    viewName: data.viewName
                }
            });
            this.set("value", context);
            // display top notification bar
            this.overviewWidget.showNotification();
        },

        _setValueAttr: function (value) {
            this.overviewWidget.set("value", value);
        },

        layout: function () {
            // summary:
            //		Layout the children widgets.
            // tags:
            //		protected

            var toolbarSize = domGeometry.getMarginBox(this.toolbar.domNode);

            // Set the size of the overview widget to be the content height minus the toolbar height.
            this.overviewWidget.resize({
                h: this._contentBox.h - toolbarSize.h,
                w: this._contentBox.w
            });
        }
    });
});
