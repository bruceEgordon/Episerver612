﻿define("epi-ecf-ui/CommerceUIModule", [
// dojo
    "dojo/_base/declare",
// epi
    "epi/_Module",
    "epi/routes",
    "epi/dependency",
    "epi/shell/store/Registry",
    "epi/shell/ClipboardManager",
    "epi-cms/store/CustomQueryEngine",

    "epi-ecf-ui/FacetFiltersService",
    "./command/MarketingToolbarCommandProvider",
    "epi-ecf-ui/plugin-area/_CommerceEditViewFilter"
], function (
// dojo
    declare,
// epi
    _Module,
    routes,
    dependency,
    Registry,
    ClipboardManager,
    CustomQueryEngine,

    FacetFiltersService,
    MarketingToolbarCommandProvider,
    _CommerceEditViewFilter
) {

    return declare([_Module], {
        // summary: this is the initializer of CommerceUIModule.

        //  _settings: [protected override] Object
        //      Settings object
        _settings: null,

        // _hashWrapper: Object
        //    HashWrapper instance, which will be used to manipulate hash.
        _hashWrapper: null,

        constructor: function (settings) {
            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //		Initialize module
            //
            // description:
            //

            this.inherited(arguments);

            // Initialize stores
            this._initializeStores();

            this._initializeCommands();

            // Initialize global/singleton instance
            this._initializeGlobalInstances();

            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");

            // Call onContextChange for epi.commerce.campaignitem routes.
            var contextService = this.resolveDependency("epi.shell.ContextService");
            contextService.registerRoute("epi.commerce.campaign", this._redirectCampaignContext.bind(this));
        },

        _initializeStores: function () {
            var registry = this.resolveDependency("epi.storeregistry");
            registry.create("epi.commerce.market", this._getRestPath("market"), {});
            registry.create("epi.commerce.price", this._getRestPath("price"), {queryEngine: CustomQueryEngine});
            registry.create("epi.commerce.inventory", this._getRestPath("inventory"), {});
            registry.create("epi.commerce.relation", this._getRestPath("relation"), { queryEngine: CustomQueryEngine });
            registry.create("epi.commerce.association", this._getRestPath("association"), { queryEngine: CustomQueryEngine });
            registry.create("epi.commerce.customergroup", this._getRestPath("customergroup"), {});
            registry.create("epi.commerce.associationgroupdefinition", this._getRestPath("associationgroupdefinition"), {});
            registry.create("epi.commerce.relationgroupdefinition", this._getRestPath("relationgroupdefinition"), {});
            registry.create("epi.commerce.metadictionary", this._getRestPath("metadictionary"), {});
            registry.create("epi.commerce.metadictionaryitem", this._getRestPath("metadictionaryitem"), {});
            registry.create("epi.commerce.campaignitem", this._getRestPath("campaignitem"), {});
            registry.create("epi.commerce.promotions", this._getRestPath("promotions"), {});
            registry.create("epi.commerce.facet", this._getRestPath("facet"), {});
            registry.create("epi.commerce.marketingstatistics", this._getRestPath("marketingstatistics"), {});
        },

        _getRestPath: function (name) {
            return routes.getRestPath({ moduleArea: "EPiServer.Commerce.Shell", storeName: name });
        },

        _initializeCommands: function(){
            var commandregistry = dependency.resolve("epi.globalcommandregistry");
            commandregistry.registerProvider("epi.commerce.marketingToolbar", new MarketingToolbarCommandProvider());
        },

        _initializeGlobalInstances: function () {
            var registry = new Registry();
            registry.add("epi.commerce.global.clipboard", new ClipboardManager());
            dependency.register("epi.commerce.global", registry);

            this.registerDependency("epi.commerce.FacetFiltersService", new FacetFiltersService({ hashKey: "campaignFacet" }));
        },

        _redirectCampaignContext: function (context, callerData) {
            // summary:
            //      Process redirect action for content data context.
            //
            // context: Object
            //      Context from context service
            //
            // callerData: Object
            //      Sources that fire the event
            //
            // tags:
            //      Private

            this._hashWrapper.onContextChange(context, callerData);
        }
    });
});
